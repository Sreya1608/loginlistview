﻿export class User {
    id: number;
    tile: string;
    fileurl: string;   
}