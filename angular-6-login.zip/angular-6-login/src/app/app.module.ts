﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule }    from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent }  from './app.component';
import { routing }        from './app.routing';

import { AuthGuard } from './guards';
import {  AuthenticationService, UserService } from './services';
import { HomeComponent } from './home';
import { LoginComponent } from './login';

@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        routing
              
    ],
    declarations: [
        AppComponent,      
        HomeComponent,
        LoginComponent        
    ],
    providers: [
        AuthGuard,
        AuthenticationService,
        UserService,
       

    ],
    bootstrap: [AppComponent]
})

export class AppModule { }